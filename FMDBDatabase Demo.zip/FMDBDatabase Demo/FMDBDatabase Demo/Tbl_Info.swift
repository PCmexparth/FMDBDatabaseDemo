//
//  Tbl_Info.swift
//  FMDBDatabase Demo
//
//  Created by Parth Changela on 22/06/17.
//  Copyright © 2017 Micropple. All rights reserved.
//

import Foundation
import UIKit

class Tbl_Info: NSObject {

    var Id:Int = Int()
    var Name:String = String()
    var MobileNo:String = String()
    var Email:String = String()

}
